

<?php $__env->startSection('title', 'Rekap Gaji'); ?>

<?php $__env->startSection('content'); ?>
    <!-- Filter Bar -->
    <div class="card mb-4">
        <div class="card-body" style="padding: 0.75rem 1rem;">
            <form action="<?php echo e(route('admin.salary-records.index')); ?>" method="GET" class="flex items-center gap-3"
                style="flex-wrap: wrap;">
                <span class="text-muted" style="font-size: 0.85rem;">Filter:</span>
                <select name="year" class="form-control form-select" style="width: auto; min-width: 90px;">
                    <option value="">Tahun</option>
                    <?php $__currentLoopData = $years; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $year): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($year); ?>" <?php echo e(request('year') == $year ? 'selected' : ''); ?>><?php echo e($year); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <select name="month" class="form-control form-select" style="width: auto; min-width: 120px;">
                    <option value="">Bulan</option>
                    <?php for($m = 1; $m <= 12; $m++): ?>
                        <option value="<?php echo e($m); ?>" <?php echo e(request('month') == $m ? 'selected' : ''); ?>>
                            <?php echo e(\Carbon\Carbon::createFromDate(null, $m, 1)->translatedFormat('F')); ?>

                        </option>
                    <?php endfor; ?>
                </select>
                <select name="term" class="form-control form-select" style="width: auto; min-width: 100px;">
                    <option value="">Termin</option>
                    <option value="1" <?php echo e(request('term') == '1' ? 'selected' : ''); ?>>T1</option>
                    <option value="2" <?php echo e(request('term') == '2' ? 'selected' : ''); ?>>T2</option>
                </select>
                <select name="status" class="form-control form-select" style="width: auto; min-width: 100px;">
                    <option value="">Status</option>
                    <option value="pending" <?php echo e(request('status') == 'pending' ? 'selected' : ''); ?>>Pending</option>
                    <option value="paid" <?php echo e(request('status') == 'paid' ? 'selected' : ''); ?>>Dibayar</option>
                </select>
                <button type="submit" class="btn btn-primary btn-sm">Filter</button>
                <?php if(request()->hasAny(['year', 'month', 'term', 'status'])): ?>
                    <a href="<?php echo e(route('admin.salary-records.index')); ?>" class="btn btn-secondary btn-sm">Reset</a>
                <?php endif; ?>
            </form>
        </div>
    </div>

    <!-- Total Stats Box -->
    <div class="stats-grid mb-4"
        style="display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 1rem;">
        <div class="stat-card"
            style="background: var(--card-bg); border-radius: 12px; padding: 1rem 1.25rem; border: 1px solid var(--border);">
            <div class="flex items-center gap-3">
                <div class="stat-icon-sm primary"
                    style="background: rgba(var(--primary-rgb), 0.15); padding: 0.75rem; border-radius: 10px;">
                    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor"
                        style="width: 24px; height: 24px; color: var(--primary);">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                            d="M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                    </svg>
                </div>
                <div>
                    <div class="text-muted" style="font-size: 0.8rem;">Total Gaji</div>
                    <div class="font-bold" style="font-size: 1.2rem; color: var(--primary);">Rp
                        <?php echo e(number_format($totals['total_amount'], 0, ',', '.')); ?></div>
                </div>
            </div>
        </div>

        <div class="stat-card"
            style="background: var(--card-bg); border-radius: 12px; padding: 1rem 1.25rem; border: 1px solid var(--border);">
            <div class="flex items-center gap-3">
                <div class="stat-icon-sm warning"
                    style="background: rgba(245, 158, 11, 0.15); padding: 0.75rem; border-radius: 10px;">
                    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor"
                        style="width: 24px; height: 24px; color: var(--warning);">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                            d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" />
                    </svg>
                </div>
                <div>
                    <div class="text-muted" style="font-size: 0.8rem;">Pending (<?php echo e($totals['count_pending']); ?>)</div>
                    <div class="font-bold" style="font-size: 1.2rem; color: var(--warning);">Rp
                        <?php echo e(number_format($totals['total_pending'], 0, ',', '.')); ?></div>
                </div>
            </div>
        </div>

        <div class="stat-card"
            style="background: var(--card-bg); border-radius: 12px; padding: 1rem 1.25rem; border: 1px solid var(--border);">
            <div class="flex items-center gap-3">
                <div class="stat-icon-sm success"
                    style="background: rgba(16, 185, 129, 0.15); padding: 0.75rem; border-radius: 10px;">
                    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor"
                        style="width: 24px; height: 24px; color: var(--success);">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                            d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
                    </svg>
                </div>
                <div>
                    <div class="text-muted" style="font-size: 0.8rem;">Dibayar (<?php echo e($totals['count_paid']); ?>)</div>
                    <div class="font-bold" style="font-size: 1.2rem; color: var(--success);">Rp
                        <?php echo e(number_format($totals['total_paid'], 0, ',', '.')); ?></div>
                </div>
            </div>
        </div>
    </div>

    <!-- Actions -->
    <div class="flex justify-end mb-4">
        <a href="<?php echo e(route('admin.salary-records.create')); ?>" class="btn btn-primary">
            <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4v16m8-8H4" />
            </svg>
            Tambah Rekap Gaji
        </a>
    </div>

    <!-- Table -->
    <div class="card">
        <div class="table-container">
            <table class="table">
                <thead>
                    <tr>
                        <th>User</th>
                        <th>Periode</th>
                        <th>Detail</th>
                        <th>Gaji</th>
                        <th>Status</th>
                        <th>Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $records; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $record): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td>
                                <div class="flex items-center gap-2">
                                    <div class="avatar avatar-sm"><?php echo e(substr($record->user->name, 0, 1)); ?></div>
                                    <div>
                                        <div class="font-medium"><?php echo e($record->user->name); ?></div>
                                        <div class="text-xs text-muted"><?php echo e($record->user->task); ?></div>
                                    </div>
                                </div>
                            </td>
                            <td>
                                <div class="font-medium"><?php echo e($record->period_label); ?></div>
                                <span class="term-badge <?php echo e($record->term == '1' ? 't1' : 't2'); ?>"
                                    style="font-size: 0.65rem;">T<?php echo e($record->term); ?></span>
                            </td>
                            <td>
                                <div class="text-xs" style="line-height: 1.4;">
                                    <div><strong><?php echo e(number_format($record->total_hours, 1)); ?></strong> jam</div>
                                    <div><?php echo e($record->total_live_count); ?> live • <?php echo e($record->total_sales); ?> penjualan</div>
                                    <?php if($record->total_content_edit || $record->total_content_live): ?>
                                        <div><?php echo e($record->total_content_edit); ?> edit • <?php echo e($record->total_content_live); ?> konten live
                                        </div>
                                    <?php endif; ?>
                                </div>
                            </td>
                            <td class="font-medium" style="color: var(--success);">
                                <?php echo e($record->formatted_amount); ?>

                            </td>
                            <td>
                                <?php if($record->status === 'paid'): ?>
                                    <span class="badge badge-success">Dibayar</span>
                                <?php else: ?>
                                    <span class="badge badge-warning">Pending</span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <div class="action-btns">
                                    <a href="<?php echo e(route('admin.salary-records.show', $record)); ?>"
                                        class="btn btn-secondary btn-sm btn-icon" title="Detail & Download">
                                        <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24"
                                            stroke="currentColor" width="16" height="16">
                                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                                d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" />
                                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                                d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z" />
                                        </svg>
                                    </a>
                                    <a href="<?php echo e(route('admin.salary-records.edit', $record)); ?>"
                                        class="btn btn-secondary btn-sm btn-icon" title="Edit">
                                        <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24"
                                            stroke="currentColor" width="16" height="16">
                                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                                d="M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z" />
                                        </svg>
                                    </a>
                                    <?php if($record->status !== 'paid'): ?>
                                        <form action="<?php echo e(route('admin.salary-records.mark-paid', $record)); ?>" method="POST"
                                            style="display:inline;">
                                            <?php echo csrf_field(); ?>
                                            <button type="submit" class="btn btn-success btn-sm btn-icon" title="Tandai Dibayar">
                                                <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24"
                                                    stroke="currentColor" width="16" height="16">
                                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                                        d="M5 13l4 4L19 7" />
                                                </svg>
                                            </button>
                                        </form>
                                    <?php endif; ?>
                                    <form action="<?php echo e(route('admin.salary-records.destroy', $record)); ?>" method="POST"
                                        style="display:inline;" onsubmit="return confirm('Hapus data ini?')">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>
                                        <button type="submit" class="btn btn-danger btn-sm btn-icon" title="Hapus">
                                            <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24"
                                                stroke="currentColor" width="16" height="16">
                                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                                    d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" />
                                            </svg>
                                        </button>
                                    </form>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="6" class="text-center text-muted" style="padding: 3rem;">
                                Tidak ada data rekap gaji. <a href="<?php echo e(route('admin.salary-records.create')); ?>">Tambah
                                    sekarang</a>
                            </td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
        <?php if($records->hasPages()): ?>
            <div class="card-footer">
                <?php echo e($records->withQueryString()->links()); ?>

            </div>
        <?php endif; ?>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\Tiktok Live Manager\resources\views/admin/salary-records/index.blade.php ENDPATH**/ ?>