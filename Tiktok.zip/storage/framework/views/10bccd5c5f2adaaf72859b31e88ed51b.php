<!-- Sidebar -->
<aside class="sidebar">
    <div class="sidebar-header">
        <img src="<?php echo e(asset('images/logo.png')); ?>" alt="Logo" class="sidebar-logo-img"
            style="width: 40px; height: 40px; border-radius: 8px; object-fit: cover;">
        <div>
            <div class="sidebar-title">TikTok Live</div>
            <div class="sidebar-subtitle">Manager</div>
        </div>
    </div>

    <nav class="sidebar-nav">
        <?php if(auth()->user()->isAdmin()): ?>
            <!-- Admin Navigation -->
            <div class="nav-group">
                <div class="nav-group-title">Menu Utama</div>
                <a href="<?php echo e(route('admin.dashboard')); ?>"
                    class="nav-item <?php echo e(request()->routeIs('admin.dashboard') ? 'active' : ''); ?>">
                    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                            d="M3 12l2-2m0 0l7-7 7 7M5 10v10a1 1 0 001 1h3m10-11l2 2m-2-2v10a1 1 0 01-1 1h-3m-6 0a1 1 0 001-1v-4a1 1 0 011-1h2a1 1 0 011 1v4a1 1 0 001 1m-6 0h6" />
                    </svg>
                    Dashboard
                </a>
                <a href="<?php echo e(route('admin.attendances.index')); ?>"
                    class="nav-item <?php echo e(request()->routeIs('admin.attendances.*') ? 'active' : ''); ?>">
                    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                            d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2m-3 7h3m-3 4h3m-6-4h.01M9 16h.01" />
                    </svg>
                    Riwayat Absensi
                </a>
                <a href="<?php echo e(route('admin.salaries.index')); ?>"
                    class="nav-item <?php echo e(request()->routeIs('admin.salaries.*') ? 'active' : ''); ?>">
                    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                            d="M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                    </svg>
                    Riwayat Gaji
                </a>
                <a href="<?php echo e(route('admin.salary-records.index')); ?>"
                    class="nav-item <?php echo e(request()->routeIs('admin.salary-records.*') ? 'active' : ''); ?>">
                    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                            d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
                    </svg>
                    Rekap Gaji
                </a>
            </div>

            <div class="nav-group">
                <div class="nav-group-title">Manajemen</div>
                <a href="<?php echo e(route('admin.users.index')); ?>"
                    class="nav-item <?php echo e(request()->routeIs('admin.users.*') ? 'active' : ''); ?>">
                    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                            d="M12 4.354a4 4 0 110 5.292M15 21H3v-1a6 6 0 0112 0v1zm0 0h6v-1a6 6 0 00-9-5.197M13 7a4 4 0 11-8 0 4 4 0 018 0z" />
                    </svg>
                    Pengguna
                </a>
                <a href="<?php echo e(route('admin.salary-schemes.index')); ?>"
                    class="nav-item <?php echo e(request()->routeIs('admin.salary-schemes.*') ? 'active' : ''); ?>">
                    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                            d="M9 7h6m0 10v-3m-3 3h.01M9 17h.01M9 14h.01M12 14h.01M15 11h.01M12 11h.01M9 11h.01M7 21h10a2 2 0 002-2V5a2 2 0 00-2-2H7a2 2 0 00-2 2v14a2 2 0 002 2z" />
                    </svg>
                    Kontrol Gaji
                </a>
                <a href="<?php echo e(route('admin.bonus-tiers.index')); ?>"
                    class="nav-item <?php echo e(request()->routeIs('admin.bonus-tiers.*') ? 'active' : ''); ?>">
                    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                            d="M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                    </svg>
                    Skema Bonus
                </a>
                <a href="<?php echo e(route('admin.tiktok-reports.index')); ?>"
                    class="nav-item <?php echo e(request()->routeIs('admin.tiktok-reports.*') ? 'active' : ''); ?>">
                    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                            d="M9 17v-2m3 2v-4m3 4v-6m2 10H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
                    </svg>
                    Report TikTok
                </a>
            </div>

            <div class="nav-group">
                <div class="nav-group-title">Lainnya</div>
                <a href="<?php echo e(route('admin.profile.index')); ?>"
                    class="nav-item <?php echo e(request()->routeIs('admin.profile.*') ? 'active' : ''); ?>">
                    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                            d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z" />
                    </svg>
                    Profil Saya
                </a>
                <a href="<?php echo e(route('admin.settings.index')); ?>"
                    class="nav-item <?php echo e(request()->routeIs('admin.settings.*') ? 'active' : ''); ?>">
                    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                            d="M10.325 4.317c.426-1.756 2.924-1.756 3.35 0a1.724 1.724 0 002.573 1.066c1.543-.94 3.31.826 2.37 2.37a1.724 1.724 0 001.065 2.572c1.756.426 1.756 2.924 0 3.35a1.724 1.724 0 00-1.066 2.573c.94 1.543-.826 3.31-2.37 2.37a1.724 1.724 0 00-2.572 1.065c-.426 1.756-2.924 1.756-3.35 0a1.724 1.724 0 00-2.573-1.066c-1.543.94-3.31-.826-2.37-2.37a1.724 1.724 0 00-1.065-2.572c-1.756-.426-1.756-2.924 0-3.35a1.724 1.724 0 001.066-2.573c-.94-1.543.826-3.31 2.37-2.37.996.608 2.296.07 2.572-1.065z" />
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                            d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" />
                    </svg>
                    Pengaturan
                </a>
            </div>
        <?php else: ?>
            <!-- User Navigation -->
            <div class="nav-group">
                <div class="nav-group-title">Menu</div>
                <a href="<?php echo e(route('user.dashboard')); ?>"
                    class="nav-item <?php echo e(request()->routeIs('user.dashboard') ? 'active' : ''); ?>">
                    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                            d="M3 12l2-2m0 0l7-7 7 7M5 10v10a1 1 0 001 1h3m10-11l2 2m-2-2v10a1 1 0 01-1 1h-3m-6 0a1 1 0 001-1v-4a1 1 0 011-1h2a1 1 0 011 1v4a1 1 0 001 1m-6 0h6" />
                    </svg>
                    Dashboard
                </a>
                <a href="<?php echo e(route('user.attendances.create')); ?>"
                    class="nav-item <?php echo e(request()->routeIs('user.attendances.create') ? 'active' : ''); ?>">
                    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                            d="M12 9v3m0 0v3m0-3h3m-3 0H9m12 0a9 9 0 11-18 0 9 9 0 0118 0z" />
                    </svg>
                    Input Absensi
                </a>
                <a href="<?php echo e(route('user.attendances.index')); ?>"
                    class="nav-item <?php echo e(request()->routeIs('user.attendances.index') ? 'active' : ''); ?>">
                    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                            d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2" />
                    </svg>
                    Riwayat Absensi
                </a>
                <a href="<?php echo e(route('user.settings.index')); ?>"
                    class="nav-item <?php echo e(request()->routeIs('user.settings.*') ? 'active' : ''); ?>">
                    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                            d="M10.325 4.317c.426-1.756 2.924-1.756 3.35 0a1.724 1.724 0 002.573 1.066c1.543-.94 3.31.826 2.37 2.37a1.724 1.724 0 001.065 2.572c1.756.426 1.756 2.924 0 3.35a1.724 1.724 0 00-1.066 2.573c.94 1.543-.826 3.31-2.37 2.37a1.724 1.724 0 00-2.572 1.065c-.426 1.756-2.924 1.756-3.35 0a1.724 1.724 0 00-2.573-1.066c-1.543.94-3.31-.826-2.37-2.37a1.724 1.724 0 00-1.065-2.572c-1.756-.426-1.756-2.924 0-3.35a1.724 1.724 0 001.066-2.573c-.94-1.543.826-3.31 2.37-2.37.996.608 2.296.07 2.572-1.065z" />
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                            d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" />
                    </svg>
                    Pengaturan
                </a>
            </div>
        <?php endif; ?>
    </nav>

    <div class="sidebar-footer">
        <div class="flex items-center gap-3">
            <div class="avatar"><?php echo e(substr(auth()->user()->name, 0, 1)); ?></div>
            <div class="flex-1 truncate">
                <div class="font-medium text-sm truncate"><?php echo e(auth()->user()->name); ?></div>
                <div class="text-xs text-muted"><?php echo e(auth()->user()->task ?? auth()->user()->role); ?></div>
            </div>
        </div>
    </div>
</aside><?php /**PATH C:\laragon\www\Tiktok Live Manager\resources\views/layouts/partials/sidebar.blade.php ENDPATH**/ ?>