# Quick Reference - UI Updates Deployment

## 📁 Files to Upload (18 total)

### Controllers (4)
✅ `app/Http/Controllers/Admin/AttendanceController.php`
✅ `app/Http/Controllers/Admin/SalaryController.php`
✅ `app/Http/Controllers/Admin/SalaryRecordController.php`
✅ `app/Http/Controllers/User/DashboardController.php`

### Models (2)
✅ `app/Models/BonusTier.php`
✅ `app/Models/Salary.php`

### CSS (1) - IMPORTANT!
✅ `public/css/app.css` (Mobile table fixes)

### Views - Admin (6)
✅ `resources/views/admin/attendances/index.blade.php` (Mobile fix)
✅ `resources/views/admin/salary-records/index.blade.php`
✅ `resources/views/admin/salary-records/slip.blade.php`
✅ `resources/views/admin/tiktok-reports/index.blade.php`
✅ `resources/views/admin/users/create.blade.php`
✅ `resources/views/admin/users/edit.blade.php`

### Views - Layout (2)
✅ `resources/views/layouts/partials/bottom-nav.blade.php`
✅ `resources/views/layouts/partials/sidebar.blade.php`

### Views - User (2)
✅ `resources/views/user/attendances/index.blade.php`
✅ `resources/views/user/dashboard.blade.php`

### Routes (1)
✅ `routes/web.php`

## 🚀 Quick Steps

1. **Upload files** via FTP/cPanel to matching paths
2. **Clear cache** via SSH:
   ```bash
   php artisan route:clear
   php artisan config:clear
   php artisan cache:clear
   php artisan view:clear
   ```
3. **Test** mobile view on admin attendance page

## ⚠️ Critical
- Backup first!
- Clear browser cache (Ctrl+F5) after deployment
- Main fix: Mobile table now fits without scroll
