

<?php $__env->startSection('title', 'Tambah Rekap Gaji'); ?>

<?php $__env->startSection('content'); ?>
    <div class="card" style="max-width: 600px; margin: 0 auto;">
        <div class="card-header">
            <h3 class="card-title">Tambah Rekap Gaji</h3>
        </div>
        <div class="card-body">
            <form action="<?php echo e(route('admin.salary-records.store')); ?>" method="POST">
                <?php echo csrf_field(); ?>

                <div class="form-group">
                    <label class="form-label">User <span class="text-danger">*</span></label>
                    <select name="user_id" id="user_id" class="form-control form-select" required>
                        <option value="">Pilih User</option>
                        <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($user->id); ?>" 
                                data-hourly-rate="<?php echo e($user->salaryScheme->hourly_rate ?? 0); ?>"
                                data-content-edit-rate="<?php echo e($user->salaryScheme->content_edit_rate ?? 0); ?>"
                                data-content-live-rate="<?php echo e($user->salaryScheme->content_live_rate ?? 0); ?>"
                                data-sales-bonus="<?php echo e($user->salaryScheme->sales_bonus_nominal ?? 0); ?>"
                                <?php echo e(old('user_id') == $user->id ? 'selected' : ''); ?>>
                                <?php echo e($user->name); ?> - <?php echo e($user->task); ?>

                            </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    <?php $__errorArgs = ['user_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="text-danger" style="font-size: 0.8rem;"><?php echo e($message); ?></span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div class="grid grid-2 gap-4">
                    <div class="form-group">
                        <label class="form-label">Tahun <span class="text-danger">*</span></label>
                        <select name="year" id="year" class="form-control form-select" required>
                            <?php for($y = now()->year; $y >= 2020; $y--): ?>
                                <option value="<?php echo e($y); ?>" <?php echo e(old('year', now()->year) == $y ? 'selected' : ''); ?>><?php echo e($y); ?></option>
                            <?php endfor; ?>
                        </select>
                    </div>
                    <div class="form-group">
                        <label class="form-label">Bulan <span class="text-danger">*</span></label>
                        <select name="month" id="month" class="form-control form-select" required>
                            <?php for($m = 1; $m <= 12; $m++): ?>
                                <option value="<?php echo e($m); ?>" <?php echo e(old('month', now()->month) == $m ? 'selected' : ''); ?>>
                                    <?php echo e(\Carbon\Carbon::createFromDate(null, $m, 1)->translatedFormat('F')); ?>

                                </option>
                            <?php endfor; ?>
                        </select>
                    </div>
                </div>

                <div class="form-group">
                    <label class="form-label">Termin <span class="text-danger">*</span></label>
                    <div class="flex gap-4">
                        <label class="flex items-center gap-2">
                            <input type="radio" name="term" id="term1" value="1" <?php echo e(old('term', '1') == '1' ? 'checked' : ''); ?> required>
                            <span>T1 (Tanggal 1-15)</span>
                        </label>
                        <label class="flex items-center gap-2">
                            <input type="radio" name="term" id="term2" value="2" <?php echo e(old('term') == '2' ? 'checked' : ''); ?>>
                            <span>T2 (Tanggal 16-akhir)</span>
                        </label>
                    </div>
                </div>

                <div class="form-group">
                    <label class="form-label">Jumlah Gaji <span class="text-danger">*</span></label>
                    <input type="number" name="amount" id="amount" class="form-control" value="<?php echo e(old('amount')); ?>"
                        placeholder="Contoh: 1500000" min="0" step="1000" required>
                    <small class="text-muted" id="salary-hint">Pilih user untuk menghitung gaji otomatis</small>
                    <?php $__errorArgs = ['amount'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="text-danger" style="font-size: 0.8rem;"><?php echo e($message); ?></span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div class="form-group">
                    <label class="form-label">Catatan</label>
                    <textarea name="notes" class="form-control" rows="2"
                        placeholder="Catatan tambahan (opsional)"><?php echo e(old('notes')); ?></textarea>
                </div>

                <div class="form-group">
                    <label class="form-label">Status <span class="text-danger">*</span></label>
                    <select name="status" class="form-control form-select" required>
                        <option value="pending" <?php echo e(old('status', 'pending') == 'pending' ? 'selected' : ''); ?>>Pending</option>
                        <option value="paid" <?php echo e(old('status') == 'paid' ? 'selected' : ''); ?>>Sudah Dibayar</option>
                    </select>
                </div>

                <div class="flex gap-3 mt-6">
                    <button type="submit" class="btn btn-primary">
                        <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7" />
                        </svg>
                        Simpan
                    </button>
                    <a href="<?php echo e(route('admin.salary-records.index')); ?>" class="btn btn-secondary">Batal</a>
                </div>
            </form>
        </div>
    </div>

    <!-- Attendance data for salary calculation -->
    <script>
        const attendanceData = <?php echo json_encode($attendanceData ?? [], 15, 512) ?>;
    </script>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
document.addEventListener('DOMContentLoaded', function() {
    const userSelect = document.getElementById('user_id');
    const yearSelect = document.getElementById('year');
    const monthSelect = document.getElementById('month');
    const term1Radio = document.getElementById('term1');
    const term2Radio = document.getElementById('term2');
    const amountInput = document.getElementById('amount');
    const salaryHint = document.getElementById('salary-hint');

    function calculateSalary() {
        const userId = userSelect.value;
        const year = yearSelect.value;
        const month = monthSelect.value;
        const term = term1Radio.checked ? '1' : (term2Radio.checked ? '2' : '');

        if (!userId || !year || !month || !term) {
            return;
        }

        // Build key for lookup
        const key = `${userId}-${year}-${month}-${term}`;
        const data = attendanceData[key];

        if (data) {
            amountInput.value = Math.round(data.salary);
            salaryHint.textContent = `Jam: ${data.hours} | Edit: ${data.content_edit} | Live: ${data.content_live} | Sales: ${data.sales}`;
        } else {
            salaryHint.textContent = 'Tidak ada data absensi untuk periode ini';
        }
    }

    userSelect.addEventListener('change', calculateSalary);
    yearSelect.addEventListener('change', calculateSalary);
    monthSelect.addEventListener('change', calculateSalary);
    term1Radio.addEventListener('change', calculateSalary);
    term2Radio.addEventListener('change', calculateSalary);

    // Calculate on load if user is pre-selected
    if (userSelect.value) {
        calculateSalary();
    }
});
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/diantar2/live.groovy-media.com/resources/views/admin/salary-records/create.blade.php ENDPATH**/ ?>