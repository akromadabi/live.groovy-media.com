

<?php $__env->startSection('title', 'Edit Absensi'); ?>

<?php $__env->startSection('content'); ?>
    <div class="mb-4">
        <a href="<?php echo e(route('user.attendances.index')); ?>" class="btn btn-secondary btn-sm">
            <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10 19l-7-7m0 0l7-7m-7 7h18" />
            </svg>
            Kembali
        </a>
    </div>

    <div class="card mobile-card">
        <div class="card-header">
            <h3 class="card-title">Edit Absensi</h3>
        </div>
        <div class="card-body">
            <?php
                // Calculate decimal hours from minutes
                $currentHours = $attendance->live_duration_minutes / 60;
                // Round to nearest 0.5
                $currentHours = round($currentHours * 2) / 2;
            ?>
            
            <form action="<?php echo e(route('user.attendances.update', $attendance)); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PUT'); ?>

                <div class="form-group">
                    <label for="attendance_date" class="form-label">Tanggal</label>
                    <input type="date" name="attendance_date" id="attendance_date" class="form-control"
                        value="<?php echo e(old('attendance_date', $attendance->attendance_date->format('Y-m-d'))); ?>"
                        max="<?php echo e(date('Y-m-d')); ?>" required>
                </div>

                <div class="form-group">
                    <label for="live_duration_hours" class="form-label">Durasi Live (Jam)</label>
                    <select name="live_duration_hours" id="live_duration_hours" class="form-control form-select" required>
                        <option value="">Pilih Durasi</option>
                        <?php $__currentLoopData = [1, 1.5, 2, 2.5, 3, 3.5, 4, 4.5]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $duration): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($duration); ?>" <?php echo e(old('live_duration_hours', $currentHours) == $duration ? 'selected' : ''); ?>>
                                <?php echo e($duration); ?> Jam
                            </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>

                <div class="form-row">
                    <div class="form-group">
                        <label for="content_edit_count" class="form-label">Jumlah Konten Edit</label>
                        <select name="content_edit_count" id="content_edit_count" class="form-control form-select">
                            <option value="0" <?php echo e(old('content_edit_count', $attendance->content_edit_count) == 0 ? 'selected' : ''); ?>>0</option>
                            <?php $__currentLoopData = [1, 2, 3, 4]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $count): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($count); ?>" <?php echo e(old('content_edit_count', $attendance->content_edit_count) == $count ? 'selected' : ''); ?>>
                                    <?php echo e($count); ?>

                                </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="content_live_count" class="form-label">Jumlah Konten Live</label>
                        <select name="content_live_count" id="content_live_count" class="form-control form-select">
                            <option value="0" <?php echo e(old('content_live_count', $attendance->content_live_count) == 0 ? 'selected' : ''); ?>>0</option>
                            <?php $__currentLoopData = [1, 2, 3, 4]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $count): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($count); ?>" <?php echo e(old('content_live_count', $attendance->content_live_count) == $count ? 'selected' : ''); ?>>
                                    <?php echo e($count); ?>

                                </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                </div>

                <div class="form-group">
                    <label for="sales_count" class="form-label">Jumlah Penjualan</label>
                    <input type="number" name="sales_count" id="sales_count" class="form-control"
                        value="<?php echo e(old('sales_count', $attendance->sales_count)); ?>" min="0" required>
                </div>

                <div class="form-group">
                    <label for="notes" class="form-label">Catatan</label>
                    <textarea name="notes" id="notes" class="form-control"
                        rows="2"><?php echo e(old('notes', $attendance->notes)); ?></textarea>
                </div>

                <div class="flex gap-3 mt-4">
                    <button type="submit" class="btn btn-primary flex-1">Simpan Perubahan</button>
                    <a href="<?php echo e(route('user.attendances.index')); ?>" class="btn btn-secondary">Batal</a>
                </div>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/diantar2/live.groovy-media.com/resources/views/user/attendances/edit.blade.php ENDPATH**/ ?>