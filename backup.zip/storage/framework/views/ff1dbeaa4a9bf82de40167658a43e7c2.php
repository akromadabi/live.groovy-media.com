

<?php $__env->startSection('title', 'Report TikTok'); ?>

<?php $__env->startSection('content'); ?>
    <!-- Filter Bar -->
    <div class="card mb-4">
        <div class="card-body" style="padding: 1rem;">
            <form action="<?php echo e(route('admin.tiktok-reports.index')); ?>" method="GET" class="flex items-center gap-3 flex-wrap">
                <select name="year" class="form-control form-select" style="width: auto; min-width: 100px;">
                    <?php for($y = now()->year; $y >= 2020; $y--): ?>
                        <option value="<?php echo e($y); ?>" <?php echo e(request('year', now()->year) == $y ? 'selected' : ''); ?>><?php echo e($y); ?></option>
                    <?php endfor; ?>
                </select>
                <select name="month" class="form-control form-select" style="width: auto; min-width: 130px;">
                    <?php for($m = 1; $m <= 12; $m++): ?>
                        <option value="<?php echo e($m); ?>" <?php echo e(request('month', now()->month) == $m ? 'selected' : ''); ?>>
                            <?php echo e(\Carbon\Carbon::createFromDate(null, $m, 1)->translatedFormat('F')); ?>

                        </option>
                    <?php endfor; ?>
                </select>
                <button type="submit" class="btn btn-primary">
                    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                            d="M3 4a1 1 0 011-1h16a1 1 0 011 1v2.586a1 1 0 01-.293.707l-6.414 6.414a1 1 0 00-.293.707V17l-4 4v-6.586a1 1 0 00-.293-.707L3.293 7.293A1 1 0 013 6.586V4z" />
                    </svg>
                    Filter
                </button>
                <button type="button" data-modal="upload-modal" class="btn btn-success" style="margin-left: auto;">
                    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                            d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-8l-4-4m0 0L8 8m4-4v12" />
                    </svg>
                    Upload Report
                </button>
            </form>
        </div>
    </div>

    <!-- Summary Stats -->
    <div class="stats-grid-mobile mb-4">
        <div class="stat-card-compact">
            <div class="stat-icon-sm primary">
                <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                        d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2" />
                </svg>
            </div>
            <div class="stat-info">
                <div class="stat-value"><?php echo e($dailyData->count()); ?></div>
                <div class="stat-label">Hari Tercatat</div>
            </div>
        </div>
        <div class="stat-card-compact">
            <div class="stat-icon-sm success">
                <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                        d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" />
                </svg>
            </div>
            <div class="stat-info">
                <div class="stat-value"><?php echo e(number_format($totalAbsenHours, 1)); ?> jam</div>
                <div class="stat-label">Total Absen</div>
            </div>
        </div>
        <div class="stat-card-compact">
            <div class="stat-icon-sm warning">
                <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                        d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z" />
                </svg>
            </div>
            <div class="stat-info">
                <div class="stat-value"><?php echo e(number_format($totalTiktokHours, 1)); ?> jam</div>
                <div class="stat-label">Total TikTok</div>
            </div>
        </div>
    </div>

    <!-- Data Table -->
    <div class="card mb-4">
        <div class="card-header">
            <h3 class="card-title">Perbandingan Harian</h3>
        </div>
        <div class="table-container">
            <table class="table">
                <thead>
                    <tr>
                        <th>Tanggal</th>
                        <th>Absen</th>
                        <th>Report TikTok</th>
                        <th>Keterangan</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $dailyData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td>
                                <div class="font-medium"><?php echo e(\Carbon\Carbon::parse($data->date)->translatedFormat('d M Y')); ?>

                                </div>
                                <div class="text-xs text-muted"><?php echo e(\Carbon\Carbon::parse($data->date)->translatedFormat('l')); ?>

                                </div>
                            </td>
                            <td>
                                <?php if($data->absen_minutes > 0): ?>
                                    <span class="font-medium"><?php echo e(number_format($data->absen_minutes / 60, 1)); ?> jam</span>
                                <?php else: ?>
                                    <span class="text-muted">-</span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <?php if($data->tiktok_minutes > 0): ?>
                                    <span class="font-medium"><?php echo e(number_format($data->tiktok_minutes / 60, 1)); ?> jam</span>
                                <?php else: ?>
                                    <span class="text-muted">-</span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <?php
                                    $diff = $data->absen_minutes - $data->tiktok_minutes;
                                    $diffHours = abs($diff) / 60;
                                ?>
                                <?php if($data->tiktok_minutes == 0 && $data->absen_minutes > 0): ?>
                                    <span class="badge badge-warning">Belum ada data TikTok</span>
                                <?php elseif($data->absen_minutes == 0 && $data->tiktok_minutes > 0): ?>
                                    <span class="badge badge-danger">Tidak ada absen</span>
                                <?php elseif($diff == 0): ?>
                                    <span class="badge badge-success">Sesuai</span>
                                <?php elseif($diff > 0): ?>
                                    <span class="badge badge-danger">Absen +<?php echo e(number_format($diffHours, 1)); ?> jam</span>
                                <?php else: ?>
                                    <span class="badge badge-primary">TikTok +<?php echo e(number_format($diffHours, 1)); ?> jam</span>
                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="4" class="text-center text-muted" style="padding: 3rem;">
                                Tidak ada data untuk periode ini
                            </td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>

    <!-- Uploaded Files List -->
    <div class="card">
        <div class="card-header">
            <h3 class="card-title">File Report yang Diupload</h3>
        </div>
        <div class="table-container">
            <table class="table">
                <thead>
                    <tr>
                        <th>Nama File</th>
                        <th class="hide-on-mobile">Tanggal Upload</th>
                        <th class="hide-on-mobile">Total Data</th>
                        <th>Total Durasi</th>
                        <th>Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $uploadedFiles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $file): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td>
                                <div class="font-medium"><?php echo e($file->original_filename ?? $file->filename); ?></div>
                                <div class="text-xs text-muted">oleh <?php echo e($file->uploader->name ?? 'Unknown'); ?></div>
                            </td>
                            <td class="hide-on-mobile"><?php echo e($file->created_at->format('d M Y H:i')); ?></td>
                            <td class="hide-on-mobile"><?php echo e($file->total_records ?? $file->details()->count()); ?> data</td>
                            <td><?php echo e(number_format(($file->total_duration_minutes ?? $file->details()->sum('duration_minutes')) / 60, 1)); ?>

                                jam</td>
                            <td>
                                <form action="<?php echo e(route('admin.tiktok-reports.destroy', $file)); ?>" method="POST"
                                    style="display:inline;" id="delete-file-<?php echo e($file->id); ?>">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button type="button" onclick="confirmDelete('delete-file-<?php echo e($file->id); ?>')"
                                        class="btn btn-danger btn-sm btn-icon" title="Hapus">
                                        <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24"
                                            stroke="currentColor" width="16" height="16">
                                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                                d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" />
                                        </svg>
                                    </button>
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="5" class="text-center text-muted" style="padding: 2rem;">
                                Belum ada file diupload
                            </td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>

    <!-- Upload Modal -->
    <div class="modal-overlay" id="upload-modal">
        <div class="modal">
            <div class="modal-header">
                <h3 class="modal-title">Upload Report TikTok</h3>
                <button type="button" class="modal-close" data-modal-close>
                    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor" width="20"
                        height="20">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12" />
                    </svg>
                </button>
            </div>
            <form action="<?php echo e(route('admin.tiktok-reports.store')); ?>" method="POST" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <div class="modal-body">
                    <div class="form-group">
                        <label class="form-label">File Excel (.xlsx)</label>
                        <input type="file" name="report_file" class="form-control" accept=".xlsx,.xls" required>
                        <div class="form-hint">Upload file report dari TikTok dalam format Excel</div>
                    </div>
                    <div class="alert alert-info mt-3">
                        <strong>📌 Format File:</strong><br>
                        File harus memiliki kolom:<br>
                        • <strong>Start time</strong> - Format: 2026-01-29 19:16<br>
                        • <strong>Duration</strong> - Nilai dalam detik
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-modal-close>Batal</button>
                    <button type="submit" class="btn btn-primary">
                        <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-8l-4-4m0 0L8 8m4-4v12" />
                        </svg>
                        Upload & Proses
                    </button>
                </div>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/diantar2/live.groovy-media.com/resources/views/admin/tiktok-reports/index.blade.php ENDPATH**/ ?>