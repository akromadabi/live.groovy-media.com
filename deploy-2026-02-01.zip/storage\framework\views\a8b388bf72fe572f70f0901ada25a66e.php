

<?php $__env->startSection('title', 'Kontrol Gaji'); ?>

<?php $__env->startSection('content'); ?>
    <div class="card">
        <div class="table-container">
            <table class="table">
                <thead>
                    <tr>
                        <th>Pengguna</th>
                        <th>Tugas</th>
                        <th>Gaji/Jam</th>
                        <th>Gaji/Konten Edit</th>
                        <th>Gaji/Konten Live</th>
                        <th>Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td>
                                <div class="flex items-center gap-2">
                                    <div class="avatar avatar-sm"><?php echo e(substr($user->name, 0, 1)); ?></div>
                                    <span><?php echo e($user->name); ?></span>
                                </div>
                            </td>
                            <td><?php echo e($user->task ?? '-'); ?></td>
                            <td>Rp <?php echo e(number_format($user->salaryScheme->hourly_rate ?? 0, 0, ',', '.')); ?></td>
                            <td>Rp <?php echo e(number_format($user->salaryScheme->content_edit_rate ?? 0, 0, ',', '.')); ?></td>
                            <td>Rp <?php echo e(number_format($user->salaryScheme->content_live_rate ?? 0, 0, ',', '.')); ?></td>
                            <td>
                                <a href="<?php echo e(route('admin.salary-schemes.edit', $user)); ?>" class="btn btn-secondary btn-sm">
                                    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24"
                                        stroke="currentColor" width="16" height="16">
                                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                            d="M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z" />
                                    </svg>
                                    Edit
                                </a>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="6" class="text-center text-muted" style="padding: 3rem;">
                                Tidak ada pengguna
                            </td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\Tiktok Live Manager\resources\views/admin/salary-schemes/index.blade.php ENDPATH**/ ?>